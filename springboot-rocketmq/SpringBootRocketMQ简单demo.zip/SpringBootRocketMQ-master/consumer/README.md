# SpringBootRocketMQ
SpringBoot整合RocketMQ

----
#### 只需要搭建RocketMQ的服务器即可
在consumer项目中的server中有提供，按照手册启动即可
